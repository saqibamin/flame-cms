$(document).ready(function() {
	$('#add_hook_box').click(function() {
		$('#add_hook_form_container').slideToggle();		
	});
	$("#form_hide_option").click(function() {
		$('#add_hook_form_container').slideToggle();
	});
});