$(document).ready(function() {
	$('#add_q_box').click(function() {
		$('#add_q_form_container').slideToggle();		
	});
	$("#form_hide_option").click(function() {
		$('#add_q_form_container').slideToggle();
	});
});