<?php require_once('securityCheck.php'); ?>
<div id="topbar">
		<a href="index.php" title="Goto Admin Home"><h1>Admin Panel | <em style="font-weight: normal;"><?php echo get_site_title(); ?></em></h1></a>
</div>
<div class="strip"></div>