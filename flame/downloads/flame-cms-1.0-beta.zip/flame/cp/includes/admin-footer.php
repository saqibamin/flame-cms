<?php require_once('securityCheck.php'); ?>
<div id="admin-footer">
		<div class="strip"></div>
			<span>All Rights Reserved &copy; 2012-13 | <em><strong>Flame-CMS</strong></em></span>
		</div>